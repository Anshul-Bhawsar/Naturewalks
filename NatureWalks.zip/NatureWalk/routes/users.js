const express = require('express');
const passport = require('passport');
const router = express.Router();
const catchAsync = require('../utilities/catchAsync')
const userController = require('../controller/user');

router.route('/register')
    .get(userController.registerForm)
    .post(catchAsync(userController.registeringUser ));

router.route('/login')
    .get(userController.loginForm)
    .post(passport.authenticate('local', {failureFlash : true, failureRedirect : '/user/login'}),userController.loginRoute)

router.get('/logout',userController.logoutRoute)

module.exports = router;