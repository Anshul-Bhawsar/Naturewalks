const express = require('express');
const NatureWalks= require('../models/NatureWalks');
const wrapAsync = require('../utilities/catchAsync');
const router = express.Router();
const{ naturewalkSchema , reviewSchema } = require('../schema');
const{ isLoggedIn }= require('../middleware');
const { isOwner } = require('../middleware');
const { validateNaturewalk } = require('../middleware');
const naturewalk = require('../controller/naturewalk');
const multer = require("multer");
const { storage } = require("../cloudinary")
const upload = multer({ storage });

router.get('/',wrapAsync(naturewalk.index))

router.route('/create')
    .get(isLoggedIn ,naturewalk.createNaturewalkForm)
    // .post(isLoggedIn,validateNaturewalk, wrapAsync(naturewalk.createNaturewalk))
    .post(upload.array('image'),(req,res) =>{
        console.log(req.body, req.files);
        res.send("IT WORKED!!!!");
    })

router.route('/update/:id')
    .get(isLoggedIn , isOwner , wrapAsync(naturewalk.updateNaturewalkForm))
    .patch(isLoggedIn , isOwner ,validateNaturewalk,wrapAsync(naturewalk.updateNaturewalk))

router.get('/delete/:id', isLoggedIn , isOwner , wrapAsync (naturewalk.deleteNatureWalk))

router.get('/:id', wrapAsync(naturewalk.showParticularNatureWalk))

// // Campground Like Route
// router.post("/:id/like",isLoggedIn, function (req, res) {
//     NatureWalks.findById(req.params.id, function (err, foundCampground) {
//         if (err) {
//             console.log(err);
//             return res.redirect("/naturewalk");
//         }

//         // check if req.user._id exists in foundCampground.likes
//         var foundUserLike = foundCampground.likes.some(function (like) {
//             return like.equals(req.user._id);
//         });

//         if (foundUserLike) {
//             // user already liked, removing like
//             foundCampground.likes.pull(req.user._id);
//         } else {
//             // adding the new user like
//             foundCampground.likes.push(req.user);
//         }

//         foundCampground.save(function (err) {
//             if (err) {
//                 console.log(err);
//                 return res.redirect("/naturewalk");
//             }
//             return res.redirect("/naturewalk/" + foundCampground._id);
//         });
//     });
// });

// module.exports = router;

// ///////////////////////////////////////////////////////////////////////////////////////////////////////

// // SHOW - shows more info about one campground
// router.get("/:id", function (req, res) {
//     //find the campground with provided ID
//     Campground.findById(req.params.id).populate("comments likes").exec(function (err, foundCampground) {
//         if (err) {
//             console.log(err);
//         } else {
//             console.log(foundCampground)
//             //render show template with that campground
//             res.render("campgrounds/show", {campground: foundCampground});
//         }
//     });
// });

// // Campground Like Route
// router.post("/:id/like", middleware.isLoggedIn, function (req, res) {
//     Campground.findById(req.params.id, function (err, foundCampground) {
//         if (err) {
//             console.log(err);
//             return res.redirect("/campgrounds");
//         }

//         // check if req.user._id exists in foundCampground.likes
//         var foundUserLike = foundCampground.likes.some(function (like) {
//             return like.equals(req.user._id);
//         });

//         if (foundUserLike) {
//             // user already liked, removing like
//             foundCampground.likes.pull(req.user._id);
//         } else {
//             // adding the new user like
//             foundCampground.likes.push(req.user);
//         }

//         foundCampground.save(function (err) {
//             if (err) {
//                 console.log(err);
//                 return res.redirect("/campgrounds");
//             }
//             return res.redirect("/campgrounds/" + foundCampground._id);
//         });
//     });
// });



module.exports = router;