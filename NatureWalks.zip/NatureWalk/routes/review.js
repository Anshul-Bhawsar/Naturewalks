const express = require('express');
const reviewcontroller = require('../controller/review')
const router = express.Router();
const{ isLoggedIn }= require('../middleware');
const{ reviewSchema } = require('../schema');
const review = require('../models/review');
const { isReviewAuthor } = require('../middleware')

router.post('/naturewalk/:id/review',isLoggedIn, reviewcontroller.addReview);

router.delete('/deleteReview/:walkId/review/:reviewId',isLoggedIn , isReviewAuthor ,reviewcontroller.deleteReview)

module.exports = router;

// const validateReview = (req,res,next)=>{
//     const { error } = reviewSchema.validate(req.body);
//     if (error) {
//         const msg = error.details.map(el => el.message).join(',')
//         throw new ExpressError(msg, 404)
//     }else{
//         next();
//     }
// }