const mongoose = require('mongoose');
const passportLocalMangoose = require('passport-local-mongoose');
// const bcrypt = require('')
const userSchema = new mongoose.Schema({
    // username : {
    //     type : String,
    //     required : [true ,'Username Cannot be Blank']
    // },
    // password : {
    //     type : String,
    //     required : [true ,'Password Cannot be Blank']
    // },
    email : {
        type : String,
        required : [true ,'Email Cannot be Blank'],
        unique : true,
    }
})

// userSchema.pre
userSchema.pre('save', async function(next){
    // i don't know this one/////////////////////////////////////////////
    if (!this.isModified('password')) return next();
    /////////////////////////////////////////////////////////////////////
    this.password = await bcrypt.hash(this.password , 12);
    next();
})

userSchema.plugin(passportLocalMangoose);

module.exports = mongoose.model('User', userSchema);