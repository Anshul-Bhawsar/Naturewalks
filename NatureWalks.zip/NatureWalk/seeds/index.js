
const mongoose = require('mongoose');
const cities =require('./cities');
const {places, descriptors,price} = require('./seedHelpers');
const Naturewalks = require('../models/NatureWalks');
mongoose.connect('mongodb://localhost:27017/temprary', {useNewUrlParser: true, useUnifiedTopology: true})
    .then(()=>{
        console.log("MONGO CONNECTION ESTABLISHED!!! FOR NatureWalks");
    })
    .catch(err =>{
        console.log("MONGO OH NOO ERROR!!!! FOR NatureWalks");
        console.log(err);
    })

const sample = array => array[Math.floor(Math.random() * array.length)];

const seedDB = async () =>{
    await Naturewalks.deleteMany({});
    for (let i = 0; i < 50; i++) {
        const random1000= Math.floor(Math.random()* 1000);
        const walk= new Naturewalks({
            owner : '600bec08eecd489a4e97040d',
            location: `${cities[random1000].city}, ${cities[random1000].state}`,
            title :`${sample(descriptors)} ${sample(places)}`,
            price :`${sample(price)}`,
            image : 'https://source.unsplash.com/collection/1157',
            description : 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae ducimus vero consequatur nemo aliquam doloremque. Adipisci perspiciatis mollitia possimus necessitatibus distinctio molestias aperiam quidem maiores culpa? Labore fuga voluptate necessitatibus!'
        })
        await walk.save();
    }
// const walk= new Naturewalks({title: 'Purple Walk'});
//     await walk.save();
 }
seedDB().then(() =>{
    mongoose.connection.close();
})