const NatureWalks= require('../models/NatureWalks');
const Review = require('../models/review');

module.exports.addReview = async (req,res)=>{
    const { id } = req.params;
    const walk = await NatureWalks.findById(id);
    const rating =parseInt(req.body.review.rating);
    req.body.review.rating = rating;
    const reviewText = req.body.review.review;
    const newReview = new Review(req.body.review);
    newReview.author = req.user._id;
    walk.reviews.push(newReview);
    await newReview.save();
    await walk.save();
    req.flash('success','Review Added');
        res.redirect(`/naturewalk/${ id }`);
}

module.exports.deleteReview =  async (req,res)=>{
    try {        
        const { walkId, reviewId } = req.params;
        console.log(req.params);
        const walk = await NatureWalks.findByIdAndUpdate(walkId,{$pull:{reviews : reviewId }});
        const qwertyReview = await Review.findByIdAndDelete(reviewId);
        // qwertyReview.save();
        // walk.save();
    req.flash('success','Review Deleted!!!');
        res.redirect(`/naturewalk/${ walkId}`);
        // res.send(req.params);
    } catch (error) {
    console.log("ERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERRORERROR")
    }
}