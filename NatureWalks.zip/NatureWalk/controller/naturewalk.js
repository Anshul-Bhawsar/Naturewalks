const NatureWalks= require('../models/NatureWalks');

module.exports.index = async (req,res,next)=>{
    const walk = await NatureWalks.find({});
    res.render('NatureWalks/index',{ walk });
}

module.exports.createNaturewalk = async (req,res,next)=>{
    const walk= new NatureWalks(req.body.naturewalk);
    walk.owner = req.user._id;
    await walk.save();
    req.flash('success',"Naturwalk Added");
    res.redirect(`/naturewalk/${walk._id}`);
}

module.exports.createNaturewalkForm = (req,res)=>{
    res.render('NatureWalks/create');
}

module.exports.updateNaturewalkForm = async (req,res,next) =>{
// router.get('/update/:id',async (req,res,next) =>{
    const { id } =req.params;
    const walk = await NatureWalks.findById(id);
    res.render('NatureWalks/update', {walk})
}

module,exports.updateNaturewalk =  async (req,res,next) =>{
    const { id } =req.params;
    const walk1 = await NatureWalks.findByIdAndUpdate(id,{...req.body.naturewalk});
    walk1.save();
    req.flash('success','Succesfully Updated');
    res.redirect(`/naturewalk/${walk1._id}`);
}

module.exports.deleteNatureWalk = async (req,res,next)=>{
    const { id } = req.params;
    const walk1 = await NatureWalks.findByIdAndDelete(id);
    req.flash('success','Naturewalk Deleted!!');
    res.redirect('/naturewalk');
}

module.exports.showParticularNatureWalk =  async (req,res,next)=>{
    const { id } =req.params; 
    const walk = await NatureWalks.findById(id).populate({
        path :'reviews',
        populate : {
            path : 'author'
        }
    }).populate('owner').populate("comments likes");
    console.log(walk);
    if (!walk) {
        req.flash('error', 'Naturewalk Not Found!!');
        return res.redirect('/naturewalk');
    }
    res.render('NatureWalks/show',{ walk });
}