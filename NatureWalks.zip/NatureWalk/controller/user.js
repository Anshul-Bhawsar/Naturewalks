const User = require('../models/user');


module.exports.registerForm = (req,res)=>{
    res.render('auth/register');
}

module.exports.registeringUser = async (req,res)=>{
    try{
    const { email, username, password, confirmpassword} = req.body;
    const user = new User({username, email});
    if (confirmpassword == password) {
        
        const registeredUser = await User.register(user,password);
        // console.log(registeredUser)
        req.login(registeredUser, err =>{
            if (err) return next(err);
            req.flash('success' , "User cerated")
            // user.save();
            res.redirect('/naturewalk');
        })
    }else{
        req.flash('error' , "Passwords Do Not Match!!!!!!");
    res.redirect('/user/register');
    }
}catch(e){
    req.flash('error' , e.message);
    res.redirect('/user/register');
}
}

module.exports.loginForm = (req,res)=>{
    res.render('auth/login')
}

module.exports.loginRoute = (req,res)=>{
    const username= req.user.username;
    req.flash('success', 'Welcome Back ' + username + " !!");
    if (req.session.returnTo) {
        const redirecrtUrl = req.session.returnTo;
        delete req.session.returnTo;
        res.redirect(redirecrtUrl);
    }else{
        const redirecrtUrl ='/naturewalk';
        res.redirect(redirecrtUrl);
        
    }
}

module.exports.logoutRoute =  (req,res)=>{
    req.logout();
    delete req.session.returnTo;
    console.log(req.session)
    req.flash('success', 'Logout Successfull, See You Later!');
    res.redirect('/naturewalk');

}